import { Component, OnInit } from '@angular/core';

class department
{
  public deptno:number=0;
  public dname:string="";
  public loc:string="";
}

@Component({
  selector: 'app-demo4',
  templateUrl: './demo4.component.html',
  styleUrls: ['./demo4.component.css']
})
export class Demo4Component {
  public ar:department[]=[];

  constructor() 
  {
    this.ar=
    [
      {dname:"Account1",deptno:10,loc:"Hyd1"},
      {dname:"Account2",deptno:11,loc:"Hyd2"},
      {dname:"Account3",deptno:13,loc:"Hyd3"},
      {dname:"Account4",deptno:14,loc:"Hyd4"},
      {dname:"Account5",deptno:15,loc:"Hyd5"},
    ];
   }

}
