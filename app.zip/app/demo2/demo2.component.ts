import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-demo2',
  templateUrl: './demo2.component.html',
  styleUrls: ['./demo2.component.css']
})
export class Demo2Component
{
  public ar:string[]=["sita","sonu","ram","mohan","shyam","amresh"];

  public course:string[]=["Angular","JavaScript","Jquery","Html","CSS","Java"];

  public image:string[]=["image1.jpeg","image2.jpeg","image3.jpeg","image4.jpeg","image5.jpeg","image6.jpeg"];
}