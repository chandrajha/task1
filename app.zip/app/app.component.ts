import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  public empno:number=12345;
  public empname:string="amresh";
  public job:string="Manager";
  public deptno:number=20;
}
