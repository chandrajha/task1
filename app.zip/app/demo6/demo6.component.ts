//Application for login in Id and password 
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-demo6',
  templateUrl: './demo6.component.html',
  styleUrls: ['./demo6.component.css']
})
export class Demo6Component
{
  public str1:string="";
  public str2:string="";
  public str3:string="";

  public f1():void
  {
    if(this.str1=="amresh"&& this.str2=="amresh#123")
    {
      this.str3="Welcome to "+this.str1;
    }
    else
    {
      this.str3="Invalid User_id or password";
    }
  }
}