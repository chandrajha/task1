import {Pipe,PipeTransform} from "@angular/core";
@Pipe({
    name:"evenpipe"
})
export class DemoPipe11 implements PipeTransform
{
    public transform(input:number[]):number[]
    {
        let output:number[]=[];
        for(let i=0;i<input.length;i++)
        {
            if(input[i]%2==0)
            {
                output.push(input[i]);
            }
        }
        return output;
    }
}