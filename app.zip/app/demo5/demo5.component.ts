import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-demo5',
  templateUrl: './demo5.component.html',
  styleUrls: ['./demo5.component.css']
})
export class Demo5Component 
{
  public empno:number=23456;
  public ename:string="Amresh";
  public job:string="Manager";
  public salary:number=12000;
  public deptno:number=13;
  
  public img:string[]=["image1.jpg","image2.jpg","image3.jpg","image4.jpg","image5.jpg"];
  public x:boolean=false;

  public str:string="Event Binding triggered..";

  public f1():void
  {
  document.getElementById("div1").innerHTML=this.str;
  }
}
