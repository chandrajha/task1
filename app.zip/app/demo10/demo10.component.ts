import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-demo10',
  templateUrl: './demo10.component.html',
  styleUrls: ['./demo10.component.css']
})
export class Demo10Component 
{
  public uname:string="scott";
  public gender:string="M";

  public users:any[]=
  [
    {uname:"smith",gender:"M"},
    {uname:"scott",gender:"M"},
    {uname:"nancy",gender:"F"},
    {uname:"somi",gender:"F"}
  ];
}