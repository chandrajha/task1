import{Pipe,PipeTransform} from "@angular/core";
@Pipe({
    name:"genderpipe"
})
export class DemoPipe implements PipeTransform
{
    public transform(input:string):string
    {
        let output:string="";
        if(input=="F")
        {
            output="female";
        }
        if(input=="M")
        {
            output="Male";
        }
        return output;
    }
}
