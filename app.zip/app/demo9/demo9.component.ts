import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-demo9',
  templateUrl: './demo9.component.html',
  styleUrls: ['./demo9.component.css']
})
export class Demo9Component 
{
  public sname:string="amresh jha";
  public course:string="angular5";
  public email:string="Amresh@gmail.com"
  public joinDate:Date= new Date();
  public fee:number=2300;

  public x:number=5;
  public students:any[]=
  [
    {s_name:"Amresh1",city:"hyd1"},
    {s_name:"Amresh2",city:"hyd2"},
    {s_name:"Amresh3",city:"hyd3"},
    {s_name:"Amresh4",city:"hyd4"},    
    {s_name:"Amresh5",city:"hyd5"},
    {s_name:"Amresh6",city:"hyd6"},
    {s_name:"Amresh7",city:"hyd7"},
    {s_name:"Amresh8",city:"hyd7"},
    {s_name:"Amresh9",city:"hyd8"},
    {s_name:"Amresh10",city:"hyd9"},
    {s_name:"Amresh11",city:"hyd10"},
    {s_name:"Amresh12",city:"hyd11"},
    {s_name:"Amresh13",city:"hyd12"},
    {s_name:"Amresh14",city:"hyd13"},
    {s_name:"Amresh15",city:"hyd14"},
    {s_name:"Amresh16",city:"hyd15"},
    {s_name:"Amresh17",city:"hyd17"},
    {s_name:"Amresh18",city:"hyd18"},
    {s_name:"Amresh19",city:"hyd19"},
    {s_name:"Amresh20",city:"hyd20"},
  ];
}