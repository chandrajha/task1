import { Component, OnInit } from '@angular/core';
import{HttpClient} from "@angular/common/http";

@Component({
  selector: 'app-demo12',
  templateUrl: './demo12.component.html',
  styleUrls: ['./demo12.component.css']
})
export class Demo12Component implements OnInit 
{
  public ar:any[]=[];
  constructor(private _httpObj:HttpClient) 
  { 

  }
  
  public fn_getData():void
  {
    var url:string="https://www.w3schools.com/angular/customers.php";
    this._httpObj.get(url).subscribe((data:any)=>
    {
      this.ar=data.records;
    });
  }

  ngOnInit() {
}

}
