import { Component, OnInit } from '@angular/core';
import {HttpClient} from "@angular/common/http";
@Component({
  selector: 'app-demo13',
  templateUrl: './demo13.component.html',
  styleUrls: ['./demo13.component.css']
})
export class Demo13Component implements OnInit 
{
  public ar:any[]=[];

  constructor(public httpObj:HttpClient) 
  { 

  }
  public getData():void
  {
    var url:string="https://www.w3schools.com/angular/customers.php";
    this.httpObj.get(url).subscribe((data:any)=>{
      this.ar=data.records;
    });
  }

  ngOnInit() {
  }

}
