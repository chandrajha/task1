import { Component, OnInit } from '@angular/core';

class department
{
  public deptno:number=0;
  public dname:string="";
  public loc:string="";
}

@Component({
  selector: 'app-demo8',
  templateUrl: './demo8.component.html',
  styleUrls: ['./demo8.component.css']
})
export class Demo8Component 
{
  public ar:department[]=[];
  
  public s1:number=0;
  public s2:string="";
  public s3:string="";

  constructor()
  {
    this.ar=
    [
      {deptno:1001,dname:"Acccount1",loc:"Hyd1"},
      {deptno:1002,dname:"Acccount2",loc:"Hyd2"},
      {deptno:1003,dname:"Acccount3",loc:"Hyd3"},
      {deptno:1004,dname:"Acccount4",loc:"Hyd4"},
      {deptno:1005,dname:"Acccount5",loc:"Hyd5"},
    ];
  }

  public addDept():void
  {
    let obj=new department();
    obj.deptno=this.s1;
    obj.dname=this.s2;
    obj.loc=this.s3;

    this.ar.push(obj);
    this.clearData();
  }
  public clearData():void
  {
    this.s1=0;
    this.s2="";
    this.s3="";
  }

  public removeItem(n:number):void
  {
    this.ar.splice(n,1);
  }

  public selectItem(n:number):void
  {
    let obj1=this.ar[n];
    this.s1=obj1.deptno;
    this.s2=obj1.dname;
    this.s3=obj1.loc;
  }
}