import { Component, OnInit } from '@angular/core';

class student
{
  public sname:string="";
  public course:string="";
  public age:number=0;
}

@Component({
  selector: 'app-demo7',
  templateUrl: './demo7.component.html',
  styleUrls: ['./demo7.component.css']
})
export class Demo7Component
{
  public ar:student[]=[];

  public s1:string="";
  public s2:string="";
  public s3:number=0;

  constructor()
  {
    this.ar=
    [
      {sname:"amresh1",course:"java1",age:23},
      {sname:"amresh2",course:"java2",age:27},
      {sname:"amresh3",course:"java3",age:28},
      {sname:"amresh4",course:"java4",age:25},
      {sname:"amresh5",course:"java5",age:22},
    ];
  }
  public addItem():void
  {
    let obj=new student();
    obj.sname=this.s1;
    obj.course=this.s2;
    obj.age=this.s3;

    this.ar.push(obj);
    this.clearFields();
  }
  public clearFields():void
  {
    this.s1="";
    this.s2="";
    this.s3=0;
  }

  public removeItem(n:number):void
  {
    this.ar.splice(n,1);
  }
  public selectItem(n:number):void
  {
    let obj=this.ar[n];
    this.s1=obj.sname;
    this.s2=obj.course;
    this.s3=obj.age;
  }
}
