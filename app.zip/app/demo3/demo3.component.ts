import { Component, OnInit } from '@angular/core';

class student
{
  public sname:string="";
  public course:string="";
  public age:number=0;
}


@Component({
  selector: 'app-demo3',
  templateUrl: './demo3.component.html',
  styleUrls: ['./demo3.component.css']
})

export class Demo3Component
{
  public ar:student[]=[];

  constructor() 
  {
    this.ar=
    [
      {sname:"amresh1",course:"java1",age:23},
      {sname:"amresh2",course:"java2",age:25},
      {sname:"amresh3",course:"java3",age:24},
      {sname:"amresh4",course:"java4",age:23},
      {sname:"amresh5",course:"java5",age:26}
    ];

  }

}
